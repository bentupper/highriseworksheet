<?php
/**
* Plugin Name: IFD Resources Plugin
* Description:  This file enqueues Javascript, CSS, and PHP files for IFD Resources
* Author: Rob McClara
* Version: 2.0
**/

/* Security - prevents hackers from getting in */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Include CSRT PHP file */
include( plugin_dir_path( __FILE__ ) . 'php/csrt-add-new-title-placeholder.php');

/* Include CSRT Page Template File */
//include( plugin_dir_path( __FILE__ ) . 'php/page-csrt-roster.php');

//echo plugins_url( '/css/main.css', __FILE__ );
/**************************************************************************************************
*
*                                Hooks in my CSS
*
***************************************************************************************************/
function ifdr_enqueue_plugin_css() {

	// echo "plugins_url() = " . plugins_url( 'ifd-resources/css/app.css' );
	// $css_timestamp = filemtime( plugins_url( 'ifd-resources/css/app.css' ) );
	// define( 'CSS_VERSION', $css_timestamp );
	// wp_register_style( 'main-style', plugins_url( '/css/app.css', __FILE__, CSS_VERSION ) );

	wp_register_style( 'main-style', plugins_url( '/css/app.css', __FILE__ ), '', '6.12.20' );
	 wp_enqueue_style( 'main-style' );

}
add_action( 'wp_enqueue_scripts', 'ifdr_enqueue_plugin_css' );


/**************************************************************************************************
*
*                       Hooks in my Javascript
*
***************************************************************************************************/
//  Front-end Scripts
function ifdr_enqueue_plugin_scripts() {

	wp_register_script( 'ifdr-custom-script', plugins_url( '/js/ifd-resources.js', __FILE__ ),        array( 'jquery', 'jquery-ui-accordion' ), false, true );
        wp_enqueue_script( 'ifdr-custom-script' );

    wp_register_script( 'ifdr-high-rise-worksheet-script', plugins_url( '/js/high-rise-worksheet.js', __FILE__ ),  array( 'jquery-ui-accordion', 'jquery-ui-datepicker' ), false, true );
        wp_enqueue_script( 'ifdr-high-rise-worksheet-script' );

    wp_register_script( 'mobile-command-script', plugins_url( '/js/mobile-command.js', __FILE__ ),    array( 'jquery', 'jquery-ui-accordion' ), false, true );
        wp_enqueue_script( 'mobile-command-script' );

}
add_action( 'wp_enqueue_scripts', 'ifdr_enqueue_plugin_scripts' );

// Admin scripts
function ifdr_enqueue_plugin_admin_scripts() {

        wp_register_script( 'ifdr-csrt-roster-admin-script', plugins_url( '/js/csrt-roster.js', __FILE__ ),          array( 'jquery-ui-datepicker' ), false, true );
         wp_enqueue_script( 'ifdr-csrt-roster-admin-script' );

}
add_action( 'admin_enqueue_scripts', 'ifdr_enqueue_plugin_admin_scripts' );

/**************************************************************************************************
*  Accidents Custom Post Type - Removes Meta Boxes in Dashboard
***************************************************************************************************/
function ifdr_accidents_cpt_remove_layout_meta_box_in_dashboard() {
	remove_meta_box( 'generate_layout_options_meta_box', 'dashboard', 'normal');
}
add_action( 'wp_dashboard_setup', 'ifdr_accidents_cpt_remove_layout_meta_box_in_dashboard' );


/******************************************************
*              Adds slashes to raw date from CPT's
*******************************************************/
function add_slashes_to_date ( $date ) {

    // Parse the string to get the month portion of the roster date (string)
    $parsed_month  = substr( $date, 0, 2 );
    // Parse the string to get the day
    $parsed_day    = substr( $date, 2, 2 );
    // Parse the string to get the year
    $parsed_year   = substr( $date, 4, 4 );
    // Insert slashes in the date
    $formatted_date = $parsed_month . '/' . $parsed_day . '/' . $parsed_year;

    return $formatted_date;
}
