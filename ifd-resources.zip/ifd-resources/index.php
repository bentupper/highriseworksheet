<?php

// Silence is golden.  :-)