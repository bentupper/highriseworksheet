jQuery(document).ready(function( $ ){

/* Disable Title bar - it is automatically updated by the date selection */
//$( 'input[name="post_title"]' ).prop( 'disabled', true );

/* Removes focus from Title and places it on the Shift */
$( '#acf-field-csrt-roster-shift-A' ).focus();



}); // end document ready